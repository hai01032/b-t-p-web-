const http = require('http');
const fs = require('fs');
const path = require('path');

// Khởi tạo server bằng module http tích hợp sẵn của Node.js
const server = http.createServer((req, res) => {
    // Lấy đường dẫn file, mặc định trả về index.html nếu truy cập root '/'
    let filePath = '.' + req.url;
    if (filePath === './') {
        filePath = './index.html';
    }

    // Xác định Content-Type dựa trên phần mở rộng của file
    const extname = String(path.extname(filePath)).toLowerCase();
    const mimeTypes = {
        '.html': 'text/html',
        '.js': 'text/javascript',
        '.css': 'text/css',
        '.json': 'application/json',
        '.png': 'image/png',
        '.jpg': 'image/jpg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml'
    };

    const contentType = mimeTypes[extname] || 'application/octet-stream';

    // Đọc và trả về nội dung file
    fs.readFile(filePath, (error, content) => {
        if (error) {
            if (error.code == 'ENOENT') {
                // Xử lý lỗi 404 (Không tìm thấy file)
                res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end('<h1>404 Not Found</h1><p>Trang bạn yêu cầu không tồn tại.</p>', 'utf-8');
            } else {
                // Lỗi server khác
                res.writeHead(500);
                res.end(`Lỗi máy chủ: ${error.code} ..\n`);
            }
        } else {
            // Trả về file HTML thành công với mã 200
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });
});

// Lắng nghe các request trên cổng 3000
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server Node.js đang chạy tại: http://localhost:${PORT}/`);
    console.log(`Hãy đảm bảo bạn đã lưu file index.html cùng thư mục với file server.js này.`);
});